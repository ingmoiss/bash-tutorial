#!/bin/bash

#Declare STRING variable
STRING="Hello World"

#Print variable on a screen
echo $STRING

